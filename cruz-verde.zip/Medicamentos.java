class Medicamento {
    String nombre;
    String dosis;
    String fechaVence;
}