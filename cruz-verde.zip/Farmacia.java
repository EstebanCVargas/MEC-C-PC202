import java.util.ArrayList;
class Farmacia {
    static ArrayList < String > listNomb;
    static ArrayList < Farmacia > listFmc;
    String nombre;
    String dirección;
    String telefono;
    ArrayList < Cita > citas;

    public static void gestionFarmacias(){
        if(listNomb == null)
            listNomb = new ArrayList< String >();
         String nombreFmc = Lectura.nextString("\n\nNombre farmacia: ");   
        if(listNomb.contains(nombreFmc.toLowerCase().replaceAll(" ", ""))){
            System.out.println("Farmacia ya existe!! ");
            crud(nombreFmc);
        } else {
            System.out.println("Farmacia nueva!! ");
            listNomb.add(nombreFmc.toLowerCase().replaceAll(" ", ""));
        }
        
    }
    public static void crud(String drogueria){
       int sel = Lectura.nextInt("\n1. Revisar 2. Cambiar 3. Eliminar\n"
        + "==>" );
       switch(sel){
           case 1: DAO.Revisar()break; //
           case 2: DAO.Cambiar()break; 
           case 3: DAO.eliminar() break;
       }
    }
}

