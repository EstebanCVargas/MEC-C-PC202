class Turno {
    int numTurno;
    String medicamento;
    
}