import java.util.ArrayList;
class CRUD {
    static ArrayList
    public static void revisar{
        
    }
    public static void cambiar{
        
    }
    public static void eliminar{
        
    }
}