import java.util.ArrayList;
class Cita {
    String fecha;
    String hora;
    String idUsuario;
    ArrayList < Turno > turnos; 
}